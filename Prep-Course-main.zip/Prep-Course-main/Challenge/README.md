---
lessonTitle: Challenge
permalink: false
eleventyNavigation:
  key: Challenge
  url: https://challenge.prep.soyhenry.com
  order: 99
---
